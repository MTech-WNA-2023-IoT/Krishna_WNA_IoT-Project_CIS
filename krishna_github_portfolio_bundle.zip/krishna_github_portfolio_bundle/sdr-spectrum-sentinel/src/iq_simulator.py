from __future__ import annotations
import numpy as np
def generate_iq(sample_rate_hz: float = 1e6, n: int = 65536) -> np.ndarray:
    rng = np.random.default_rng(21)
    t = np.arange(n) / sample_rate_hz
    sig = (1.0*np.exp(1j*2*np.pi*120e3*t) + 0.6*np.exp(1j*2*np.pi*-210e3*t) + 0.3*np.exp(1j*2*np.pi*330e3*t))
    noise = 0.18 * (rng.normal(size=n) + 1j*rng.normal(size=n))
    return sig + noise
