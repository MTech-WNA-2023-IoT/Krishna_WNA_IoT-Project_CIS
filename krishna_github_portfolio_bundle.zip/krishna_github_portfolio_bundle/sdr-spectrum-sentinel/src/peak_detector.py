from __future__ import annotations
import numpy as np, pandas as pd
def detect_peaks(freqs: np.ndarray, power_db: np.ndarray, threshold_db: float = 42.0) -> pd.DataFrame:
    rows = []
    for i in range(1, len(power_db)-1):
        if power_db[i] > threshold_db and power_db[i] > power_db[i-1] and power_db[i] > power_db[i+1]:
            rows.append({"frequency_hz": float(freqs[i]), "power_db": float(power_db[i])})
    return pd.DataFrame(rows)
