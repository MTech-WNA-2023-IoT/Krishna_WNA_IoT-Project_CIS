from __future__ import annotations
import numpy as np
def compute_spectrum(iq: np.ndarray, sample_rate_hz: float):
    spec = np.fft.fftshift(np.fft.fft(iq))
    power = 20 * np.log10(np.abs(spec) + 1e-12)
    freqs = np.fft.fftshift(np.fft.fftfreq(iq.size, d=1/sample_rate_hz))
    return freqs, power
