from __future__ import annotations
from pathlib import Path
import matplotlib.pyplot as plt
from src.iq_simulator import generate_iq
from src.peak_detector import detect_peaks
from src.spectrum_scan import compute_spectrum
def main() -> None:
    sample_rate_hz = 1e6
    iq = generate_iq(sample_rate_hz=sample_rate_hz)
    freqs, power = compute_spectrum(iq, sample_rate_hz=sample_rate_hz)
    peaks = detect_peaks(freqs, power)
    base = Path(__file__).resolve().parent
    out = base / "outputs"; out.mkdir(exist_ok=True)
    peaks.to_csv(out / "detected_peaks.csv", index=False)
    plt.figure(figsize=(8, 4.5))
    plt.plot(freqs/1e3, power)
    plt.xlabel("Frequency (kHz)"); plt.ylabel("Magnitude (dB)"); plt.title("Simulated Spectrum Scan")
    plt.tight_layout(); plt.savefig(out / "spectrum.png", dpi=160); plt.close()
    print("SDR demo completed.")
if __name__ == "__main__":
    main()
