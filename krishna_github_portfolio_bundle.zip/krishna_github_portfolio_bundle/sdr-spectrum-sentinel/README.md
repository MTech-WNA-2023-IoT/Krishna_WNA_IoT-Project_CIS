# SDR Spectrum Sentinel

A lightweight SDR-inspired signal-analysis project for:
- synthetic IQ generation
- FFT-based spectrum scan
- peak detection
- rough occupancy estimation

## Run
```bash
pip install -r requirements.txt
python run_demo.py
```
