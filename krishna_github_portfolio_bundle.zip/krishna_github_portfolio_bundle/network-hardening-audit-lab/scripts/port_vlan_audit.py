from __future__ import annotations
import re
from pathlib import Path
import pandas as pd
PORT_RE = re.compile(r"^(?P<port>Gi\d+/\d+)\s+(?P<mode>access|trunk)\s+vlan\s+(?P<vlan>\d+)\s+(?P<status>up|down)$", re.IGNORECASE)
def parse_ports(text: str) -> pd.DataFrame:
    rows = []
    for line in text.splitlines():
        m = PORT_RE.match(line.strip())
        if m:
            rows.append(m.groupdict())
    return pd.DataFrame(rows)
def audit(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(columns=["finding", "count"])
    findings = [
        {"finding": "access_ports_down", "count": int(((df["mode"] == "access") & (df["status"] == "down")).sum())},
        {"finding": "trunks_on_default_vlan_1", "count": int(((df["mode"] == "trunk") & (df["vlan"] == "1")).sum())},
        {"finding": "access_ports_vlan_1", "count": int(((df["mode"] == "access") & (df["vlan"] == "1")).sum())},
    ]
    return pd.DataFrame(findings)
def main() -> None:
    base = Path(__file__).resolve().parent.parent
    sample = (base / "samples" / "device_backup_show_run.txt").read_text(encoding="utf-8")
    ports = parse_ports(sample)
    out = base / "outputs"; out.mkdir(exist_ok=True)
    ports.to_csv(out / "parsed_ports.csv", index=False)
    audit(ports).to_csv(out / "audit_summary.csv", index=False)
    print("Network audit reports created.")
if __name__ == "__main__":
    main()
