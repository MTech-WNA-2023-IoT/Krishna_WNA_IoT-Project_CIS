# Network Hardening Audit Lab

A compact network-operations portfolio project focused on:
- backup discipline,
- VLAN / port review,
- simple config checks,
- secure access recommendations,
- structured audit outputs.

## Run
```bash
pip install -r requirements.txt
python scripts/port_vlan_audit.py
```
