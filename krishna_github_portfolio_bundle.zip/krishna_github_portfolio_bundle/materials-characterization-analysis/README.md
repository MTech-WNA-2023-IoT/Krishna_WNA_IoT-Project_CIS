# Materials Characterization Analysis

A compact scientific-analysis repository for public demonstration of:
- XRD-style peak finding,
- transport-property trend analysis,
- thermoelectric post-processing,
- quick plotting for material screening.

## Run
```bash
pip install -r requirements.txt
python run_demo.py
```
