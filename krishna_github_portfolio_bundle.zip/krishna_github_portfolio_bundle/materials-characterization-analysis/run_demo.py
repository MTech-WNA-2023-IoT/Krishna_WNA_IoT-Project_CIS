from __future__ import annotations
from pathlib import Path
import matplotlib.pyplot as plt, pandas as pd
from src.thermoelectric_metrics import compute_zt
from src.xrd_peak_finder import find_peaks
def main() -> None:
    base = Path(__file__).resolve().parent
    out = base / "outputs"; out.mkdir(exist_ok=True)
    xrd = pd.read_csv(base / "data" / "sample_xrd.csv")
    peaks = find_peaks(xrd["two_theta_deg"].to_numpy(), xrd["intensity"].to_numpy())
    peaks.to_csv(out / "xrd_peaks.csv", index=False)
    plt.figure(figsize=(8, 4.5))
    plt.plot(xrd["two_theta_deg"], xrd["intensity"])
    plt.xlabel("2θ (deg)"); plt.ylabel("Intensity (a.u.)"); plt.title("Synthetic XRD Pattern")
    plt.tight_layout(); plt.savefig(out / "xrd_pattern.png", dpi=160); plt.close()
    te = pd.read_csv(base / "data" / "sample_thermoelectric.csv")
    compute_zt(te).to_csv(out / "zt_summary.csv", index=False)
    print("Materials analysis demo completed.")
if __name__ == "__main__":
    main()
