from __future__ import annotations
import pandas as pd
def compute_zt(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["sigma_s_per_m"] = 1.0 / out["resistivity_ohm_m"]
    out["power_factor_w_mk2"] = (out["seebeck_v_per_k"] ** 2) * out["sigma_s_per_m"]
    out["zt"] = out["power_factor_w_mk2"] * out["temperature_k"] / out["thermal_conductivity_w_mk"]
    return out
