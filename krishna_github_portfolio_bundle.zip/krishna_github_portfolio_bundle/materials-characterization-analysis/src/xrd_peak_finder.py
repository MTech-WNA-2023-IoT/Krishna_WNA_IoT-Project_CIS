from __future__ import annotations
import numpy as np, pandas as pd
def find_peaks(two_theta: np.ndarray, intensity: np.ndarray, threshold: float = 0.45) -> pd.DataFrame:
    norm = intensity / intensity.max()
    rows = []
    for i in range(1, len(norm)-1):
        if norm[i] > threshold and norm[i] > norm[i-1] and norm[i] > norm[i+1]:
            rows.append({"two_theta_deg": float(two_theta[i]), "relative_intensity": float(norm[i])})
    return pd.DataFrame(rows)
