from __future__ import annotations
from pathlib import Path
from src.data_utils import add_health_columns, load_cycle_data
from src.train_models import save_report, train_and_evaluate
from src.visualize import save_capacity_plot, save_soh_plot

def main() -> None:
    base = Path(__file__).resolve().parent
    out = base / "outputs"
    out.mkdir(exist_ok=True)
    df = add_health_columns(load_cycle_data(str(base / "data" / "sample_battery_cycles.csv")))
    save_report(train_and_evaluate(df), str(out / "model_report.csv"))
    save_soh_plot(df, str(out / "soh_curve.png"))
    save_capacity_plot(df, str(out / "capacity_curve.png"))
    print("Battery demo completed.")

if __name__ == "__main__":
    main()
