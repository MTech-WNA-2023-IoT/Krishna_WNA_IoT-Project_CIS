from __future__ import annotations
import pandas as pd

def load_cycle_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"cycle", "capacity_ah", "avg_voltage_v", "avg_current_a", "avg_temp_c", "internal_resistance_ohm"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    return df.sort_values("cycle").reset_index(drop=True)

def add_health_columns(df: pd.DataFrame, rated_capacity_ah: float | None = None) -> pd.DataFrame:
    out = df.copy()
    rated = rated_capacity_ah if rated_capacity_ah is not None else float(out["capacity_ah"].iloc[0])
    out["soh_percent"] = out["capacity_ah"] / rated * 100.0
    out["rul_cycles"] = int(out["cycle"].max()) - out["cycle"]
    out["power_w"] = out["avg_voltage_v"] * out["avg_current_a"]
    return out
