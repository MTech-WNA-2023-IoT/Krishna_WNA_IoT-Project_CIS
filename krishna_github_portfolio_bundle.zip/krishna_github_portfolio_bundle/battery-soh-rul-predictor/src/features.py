from __future__ import annotations
import pandas as pd
FEATURE_COLUMNS = ["cycle", "avg_voltage_v", "avg_current_a", "avg_temp_c", "internal_resistance_ohm"]
def build_feature_matrix(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    return df[FEATURE_COLUMNS].copy(), df["capacity_ah"].copy()
