from __future__ import annotations
from dataclasses import dataclass
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from src.features import build_feature_matrix

@dataclass
class ModelResult:
    name: str
    mae: float
    r2: float

def train_and_evaluate(df: pd.DataFrame, random_state: int = 42) -> list[ModelResult]:
    X, y = build_feature_matrix(df)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=random_state)
    models = {
        "linear_regression": LinearRegression(),
        "random_forest": RandomForestRegressor(n_estimators=150, max_depth=8, random_state=random_state),
    }
    results = []
    for name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        results.append(ModelResult(name, float(mean_absolute_error(y_test, pred)), float(r2_score(y_test, pred))))
    return results

def save_report(results: list[ModelResult], output_path: str) -> None:
    pd.DataFrame([r.__dict__ for r in results]).to_csv(output_path, index=False)
