from __future__ import annotations
import matplotlib.pyplot as plt
import pandas as pd

def save_soh_plot(df: pd.DataFrame, output_path: str) -> None:
    plt.figure(figsize=(8, 4.5))
    plt.plot(df["cycle"], df["soh_percent"], linewidth=2)
    plt.axhline(80, linestyle="--")
    plt.xlabel("Cycle")
    plt.ylabel("SoH (%)")
    plt.title("Battery State of Health vs Cycle")
    plt.tight_layout()
    plt.savefig(output_path, dpi=160)
    plt.close()

def save_capacity_plot(df: pd.DataFrame, output_path: str) -> None:
    plt.figure(figsize=(8, 4.5))
    plt.plot(df["cycle"], df["capacity_ah"], linewidth=2)
    plt.xlabel("Cycle")
    plt.ylabel("Capacity (Ah)")
    plt.title("Capacity Fade vs Cycle")
    plt.tight_layout()
    plt.savefig(output_path, dpi=160)
    plt.close()
