# Battery SoH / RUL Predictor

A compact battery-health analytics project inspired by Li-ion prognostics workflows.

## What it shows
- cycle-wise battery feature generation
- SoH and RUL computation
- baseline regression models
- capacity fade visualization
- CSV report generation

## Run
```bash
pip install -r requirements.txt
python run_demo.py
```
