from __future__ import annotations
import csv, time, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import yaml
from gateway.publishers.mqtt_pub import format_payload
from gateway.sensors.mock_ads1115 import MockADS1115Sensor
def append_csv(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    file_exists = path.exists()
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)
def main() -> None:
    base = Path(__file__).resolve().parent.parent
    cfg = yaml.safe_load((base / "gateway" / "config.yaml").read_text(encoding="utf-8"))
    sensor = MockADS1115Sensor(); csv_path = base / cfg["logging"]["csv_path"]; site = cfg["site"]
    print(f"Starting gateway for site={site}")
    for _ in range(5):
        reading = sensor.read()
        payload = format_payload(site, reading)
        row = {"site": site, "voltage_v": reading.voltage_v, "current_a": reading.current_a, "temperature_c": reading.temperature_c, "humidity_percent": reading.humidity_percent, "payload": payload}
        append_csv(csv_path, row)
        print(payload); time.sleep(0.05)
    print(f"Logged readings to {csv_path}")
if __name__ == "__main__":
    main()
