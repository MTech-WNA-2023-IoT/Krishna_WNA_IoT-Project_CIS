from __future__ import annotations
from dataclasses import dataclass
from random import Random
@dataclass
class SensorReading:
    voltage_v: float
    current_a: float
    temperature_c: float
    humidity_percent: float
class MockADS1115Sensor:
    def __init__(self, seed: int = 42) -> None:
        self.rng = Random(seed)
    def read(self) -> SensorReading:
        return SensorReading(
            voltage_v=round(12.1 + self.rng.uniform(-0.4, 0.4), 3),
            current_a=round(1.25 + self.rng.uniform(-0.2, 0.2), 3),
            temperature_c=round(29 + self.rng.uniform(-1.5, 1.5), 2),
            humidity_percent=round(55 + self.rng.uniform(-4, 4), 2),
        )
