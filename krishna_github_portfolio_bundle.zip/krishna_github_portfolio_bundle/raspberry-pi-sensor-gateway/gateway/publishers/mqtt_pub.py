from __future__ import annotations
import json
def format_payload(site: str, reading: object) -> str:
    return json.dumps({"site": site, "voltage_v": reading.voltage_v, "current_a": reading.current_a, "temperature_c": reading.temperature_c, "humidity_percent": reading.humidity_percent})
