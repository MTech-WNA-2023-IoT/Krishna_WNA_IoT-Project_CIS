#!/usr/bin/env bash
set -euo pipefail
SERVICE_NAME="sensor-gateway.service"
SERVICE_PATH="/etc/systemd/system/${SERVICE_NAME}"
cat <<EOF | sudo tee "${SERVICE_PATH}" >/dev/null
[Unit]
Description=Krishna Sensor Gateway
After=network.target
[Service]
Type=simple
WorkingDirectory=/opt/raspberry-pi-sensor-gateway
ExecStart=/usr/bin/python3 /opt/raspberry-pi-sensor-gateway/gateway/main.py
Restart=on-failure
User=pi
[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable "${SERVICE_NAME}"
echo "Installed ${SERVICE_NAME}"
