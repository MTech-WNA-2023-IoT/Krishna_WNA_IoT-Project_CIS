# Raspberry Pi Sensor Gateway

A portfolio-ready edge gateway project that mimics a Raspberry Pi collecting sensor data and publishing it to MQTT.

## Design goals
- sensor abstraction layer
- CSV logging
- MQTT publishing
- deployment-friendly config file
- clean separation between acquisition and transport

## Run
```bash
pip install -r requirements.txt
python gateway/main.py
```

The default configuration uses a mock sensor so the demo can run without hardware.
