# SIP Quality Report

## Registration state
registration challenge + success observed

## Top SIP codes
100 (1), 180 (1), 200 (2), 401 (1), 403 (1)

## Overall voice-service assessment
**Moderate**

## Engineering note
Limited signaling failures were observed. Investigate auth, routing, or trunk policies.
