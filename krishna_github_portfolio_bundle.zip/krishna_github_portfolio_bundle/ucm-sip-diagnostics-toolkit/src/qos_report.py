from __future__ import annotations
from pathlib import Path
import pandas as pd
def build_quality_report(df_codes: pd.DataFrame, registration_state: str, output_path: str) -> None:
    total_failures = int(df_codes[df_codes["sip_code"] >= 300]["count"].sum()) if not df_codes.empty else 0
    top_codes = ", ".join(f'{int(row.sip_code)} ({int(row["count"])})' for _, row in df_codes.head(5).iterrows()) or "none"
    if total_failures == 0:
        quality, note = "Good", "No major SIP error bursts were found in the sample trace."
    elif total_failures <= 3:
        quality, note = "Moderate", "Limited signaling failures were observed. Investigate auth, routing, or trunk policies."
    else:
        quality, note = "Degraded", "Repeated SIP failures suggest trunk, auth, NAT, or dial-plan instability."
    text = f"""# SIP Quality Report

## Registration state
{registration_state}

## Top SIP codes
{top_codes}

## Overall voice-service assessment
**{quality}**

## Engineering note
{note}
"""
    Path(output_path).write_text(text, encoding="utf-8")
