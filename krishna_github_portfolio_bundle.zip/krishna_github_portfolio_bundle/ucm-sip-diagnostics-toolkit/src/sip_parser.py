from __future__ import annotations
import re
from collections import Counter
from pathlib import Path
import pandas as pd
SIP_CODE_RE = re.compile(r"\bSIP/(?:2\.0)\s+(\d{3})\b")
METHOD_RE = re.compile(r"\b(INVITE|REGISTER|ACK|BYE|CANCEL|OPTIONS)\b")
def parse_trace(path: str) -> pd.DataFrame:
    rows = []
    for idx, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), start=1):
        method_match = METHOD_RE.search(line)
        code_match = SIP_CODE_RE.search(line)
        rows.append({"line_no": idx, "method": method_match.group(1) if method_match else "", "sip_code": int(code_match.group(1)) if code_match else None, "raw": line.strip()})
    return pd.DataFrame(rows)
def summarize_codes(df: pd.DataFrame) -> pd.DataFrame:
    counter = Counter(int(x) for x in df["sip_code"].dropna())
    return pd.DataFrame([{"sip_code": k, "count": v} for k, v in sorted(counter.items())])
def extract_registration_state(df: pd.DataFrame) -> str:
    codes = set(int(x) for x in df["sip_code"].dropna())
    if 200 in codes and 401 in codes:
        return "registration challenge + success observed"
    if 200 in codes:
        return "registration success observed"
    if 403 in codes:
        return "forbidden / auth issue suspected"
    if 408 in codes:
        return "timeout suspected"
    return "no clear registration outcome"
