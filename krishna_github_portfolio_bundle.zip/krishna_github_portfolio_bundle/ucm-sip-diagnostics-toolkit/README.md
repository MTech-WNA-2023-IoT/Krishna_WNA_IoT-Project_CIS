# UCM SIP Diagnostics Toolkit

A practical troubleshooting project for SIP/VoIP environments.

## What it demonstrates
- SIP trace parsing
- response code summary
- registration outcome inference
- text quality report generation

## Run
```bash
pip install -r requirements.txt
python run_demo.py
```
