from __future__ import annotations
from pathlib import Path
from src.qos_report import build_quality_report
from src.sip_parser import extract_registration_state, parse_trace, summarize_codes
def main() -> None:
    base = Path(__file__).resolve().parent
    outputs = base / "outputs"; outputs.mkdir(exist_ok=True)
    df = parse_trace(str(base / "logs" / "sample_sip_trace.log"))
    codes = summarize_codes(df)
    codes.to_csv(outputs / "sip_summary.csv", index=False)
    build_quality_report(codes, extract_registration_state(df), str(outputs / "quality_report.md"))
    print("SIP diagnostics demo completed.")
if __name__ == "__main__":
    main()
