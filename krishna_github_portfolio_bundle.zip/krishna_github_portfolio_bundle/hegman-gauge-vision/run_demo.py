from __future__ import annotations
from pathlib import Path
from src.measure_dispersion import annotate, roughness_profile, save_profile_csv

def main() -> None:
    base = Path(__file__).resolve().parent
    source = base / "examples" / "sample_hegman.png"
    outputs = base / "outputs"
    outputs.mkdir(exist_ok=True)
    x, profile = roughness_profile(str(source))
    save_profile_csv(x, profile, str(outputs / "roughness_profile.csv"))
    annotate(str(source), str(outputs / "annotated_profile.png"))
    print("Hegman vision demo completed.")

if __name__ == "__main__":
    main()
