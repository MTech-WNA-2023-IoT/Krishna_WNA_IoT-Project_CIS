from __future__ import annotations
import csv
from pathlib import Path
import numpy as np
from PIL import ImageDraw
from src.preprocess import load_grayscale, normalize, smooth

def roughness_profile(path: str):
    img = smooth(normalize(load_grayscale(path)))
    arr = np.asarray(img, dtype=float) / 255.0
    gy, gx = np.gradient(arr)
    profile = np.mean(np.abs(gx) + 0.5*np.abs(gy), axis=0)
    x = np.arange(profile.size)
    return x, profile

def save_profile_csv(x, profile, path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["x_position", "roughness_score"])
        for xi, yi in zip(x, profile):
            writer.writerow([int(xi), float(yi)])

def annotate(path: str, output_path: str) -> None:
    img = normalize(load_grayscale(path)).convert("RGB")
    x, profile = roughness_profile(path)
    draw = ImageDraw.Draw(img)
    h = img.height
    prof = profile / profile.max()
    pts = [(int(i), int(h - 10 - p * (h * 0.35))) for i, p in zip(x, prof)]
    draw.line(pts, width=2)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    img.save(output_path)
