from __future__ import annotations
from PIL import Image, ImageFilter, ImageOps

def load_grayscale(path: str) -> Image.Image:
    return Image.open(path).convert("L")

def normalize(img: Image.Image) -> Image.Image:
    return ImageOps.autocontrast(img)

def smooth(img: Image.Image) -> Image.Image:
    return img.filter(ImageFilter.GaussianBlur(radius=1.0))
