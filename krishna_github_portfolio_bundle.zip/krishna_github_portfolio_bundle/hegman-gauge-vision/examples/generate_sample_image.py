from __future__ import annotations
from pathlib import Path
import numpy as np
from PIL import Image

def main() -> None:
    rng = np.random.default_rng(12)
    width, height = 720, 120
    base = np.tile(np.linspace(230, 60, width), (height, 1))
    for _ in range(900):
        x = rng.integers(0, width)
        y = rng.integers(0, height)
        radius = rng.integers(1, 4)
        val = rng.integers(20, 120)
        x0, x1 = max(0, x-radius), min(width, x+radius+1)
        y0, y1 = max(0, y-radius), min(height, y+radius+1)
        base[y0:y1, x0:x1] = val
    img = Image.fromarray(base.clip(0,255).astype("uint8"), mode="L")
    out = Path(__file__).resolve().parent / "sample_hegman.png"
    img.save(out)
    print(f"Saved {out}")

if __name__ == "__main__":
    main()
