# Hegman Gauge Vision

A small computer-vision workflow for estimating coating-dispersion trends from Hegman-gauge-style images.

## What it demonstrates
- grayscale preprocessing
- contrast normalization
- edge / roughness profile estimation
- automatic annotated output generation

## Run
```bash
pip install -r requirements.txt
python examples/generate_sample_image.py
python run_demo.py
```
